package com.example.triarb

import android.app.Application
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class LadderRow(val label: String, val profitPct: Double, val net: Double, val ok: Boolean, val unit: String)
data class DetailState(
    val hit: Hit, val loading: Boolean = true, val rows: List<LadderRow> = emptyList(),
    val legLines: List<String> = emptyList(), val error: String? = null
)

class MainVm(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("triarb", Context.MODE_PRIVATE)
    private val defaultStarts = listOf("USDT", "USDC", "BTC", "ETH", "BNB")

    val filters = MutableStateFlow(Filters())
    val fee = MutableStateFlow(0.1)
    val status = MutableStateFlow("Loading symbols…")
    val hits = MutableStateFlow<List<Hit>>(emptyList())
    val detail = MutableStateFlow<DetailState?>(null)
    val allPairs = MutableStateFlow(prefs.getBoolean("allPairs", false))
    val useRelay = MutableStateFlow(prefs.getBoolean("useRelay", false))
    val relayAddr = MutableStateFlow(prefs.getString("relayAddr", null) ?: "192.168.1.10:8765")

    private var feed: QuoteFeed? = null
    private var engine: TriangleEngine? = null
    private var job: Job? = null

    init { restart() }

    /** (Re)builds the engine and reconnects using the current feed settings. */
    fun restart() {
        prefs.edit().putBoolean("allPairs", allPairs.value).putBoolean("useRelay", useRelay.value)
            .putString("relayAddr", relayAddr.value).apply()
        job?.cancel(); feed?.close()
        engine = null; hits.value = emptyList(); detail.value = null
        val all = allPairs.value
        if (!all && filters.value.start !in (defaultStarts + "ALL")) filters.value = filters.value.copy(start = "USDT")
        val f: QuoteFeed = if (useRelay.value) RelayFeed(relayAddr.value) else BinanceFeed()
        feed = f
        job = viewModelScope.launch { run(f, all) }
    }

    private suspend fun run(f: QuoteFeed, all: Boolean) {
        try {
            status.value = "Loading symbols…"
            val syms = f.loadSymbols()
            val e = withContext(Dispatchers.Default) { TriangleEngine(syms, if (all) null else defaultStarts) }
            engine = e
            status.value = "Seeding prices… (${e.triangleCount} triangles)"
            f.seed(e)
            f.connect(e)
            var lastMsgs = 0L
            var lastT = System.currentTimeMillis()
            while (true) {
                delay(500)
                e.feePct = fee.value
                val flt = filters.value
                hits.value = withContext(Dispatchers.Default) { e.top(flt, 60) }
                val now = System.currentTimeMillis()
                val m = f.messages.get()
                val rate = (m - lastMsgs) * 1000 / maxOf(1L, now - lastT)
                lastMsgs = m; lastT = now
                val src = if (f is RelayFeed) "ccxt relay" else "Binance direct"
                status.value = "● $src · ${f.live.get()}/${f.total} sockets · $rate ticks/s · ${e.triangleCount} triangles"
            }
        } catch (ex: CancellationException) {
            throw ex
        } catch (ex: Exception) {
            status.value = "Error: ${ex.message}"
        }
    }

    fun openDetail(h: Hit) {
        val e = engine ?: return
        val f = feed ?: return
        detail.value = DetailState(h)
        viewModelScope.launch {
            val result = try {
                val books = h.legs.map { it.sym }.distinct().associateWith { f.depth(it) }
                val px = e.usdOf(h.start)
                val rows = listOf(10.0, 50.0, 100.0, 500.0, 1000.0, 5000.0, 10000.0).map { s ->
                    val startAmt = if (px > 0) s / px else s
                    val r = DepthSim.run(h.legs, books, startAmt, fee.value)
                    val net = if (r.filled) (r.endAmt - r.startAmt) * (if (px > 0) px else 1.0) else 0.0
                    LadderRow(
                        if (px > 0) "\$${s.toInt()}" else "${s.toInt()} ${h.start}",
                        r.profitPct, net, r.filled, if (px > 0) "USD" else h.start
                    )
                }
                val lines = h.legs.map { l ->
                    val b = books[l.sym]!!
                    val top = if (l.buy) b.asks.firstOrNull() else b.bids.firstOrNull()
                    val what = if (l.buy) "BUY ${l.to} with ${l.from}" else "SELL ${l.from} for ${l.to}"
                    "${l.sym}: $what @ ${top?.get(0) ?: "-"} (qty ${top?.get(1) ?: "-"})"
                }
                DetailState(h, false, rows, lines, null)
            } catch (ex: CancellationException) {
                throw ex
            } catch (ex: Exception) {
                DetailState(h, false, error = "Depth fetch failed: ${ex.message}")
            }
            if (detail.value?.hit?.id == h.id) detail.value = result
        }
    }

    fun closeDetail() { detail.value = null }
    override fun onCleared() { feed?.close() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface { Screen() } } }
    }
}

private val green = Color(0xFF4CAF50)
private val red = Color(0xFFEF5350)
private fun fmtUsd(v: Double) = when {
    v.isNaN() -> "?"
    v >= 1000 -> String.format("\$%.1fk", v / 1000)
    else -> String.format("\$%.0f", v)
}

@Composable
fun Screen(vm: MainVm = viewModel()) {
    val detail by vm.detail.collectAsState()
    val d = detail
    BackHandler(enabled = d != null) { vm.closeDetail() }
    if (d != null) DetailScreen(d, vm) else ListScreen(vm)
}

@Composable
fun ListScreen(vm: MainVm) {
    val f by vm.filters.collectAsState()
    val hits by vm.hits.collectAsState()
    val status by vm.status.collectAsState()
    val fee by vm.fee.collectAsState()
    val all by vm.allPairs.collectAsState()
    var panel by remember { mutableStateOf("") }
    val starts = if (all) listOf("ALL", "USDT", "USDC", "BTC", "ETH", "BNB", "FDUSD", "EUR", "TRY")
    else listOf("USDT", "USDC", "BTC", "ETH", "BNB")
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 12.dp)) {
        Text("TriArb · triangles", style = MaterialTheme.typography.titleLarge)
        Text(status, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            starts.forEach { s ->
                FilterChip(selected = f.start == s, onClick = { vm.filters.value = f.copy(start = s) }, label = { Text(s) })
            }
            AssistChip(onClick = { panel = if (panel == "filters") "" else "filters" }, label = { Text("Filters") })
            AssistChip(onClick = { panel = if (panel == "feed") "" else "feed" }, label = { Text("Feed") })
        }
        if (panel == "filters") FilterPanel(vm, f, fee)
        if (panel == "feed") FeedPanel(vm)
        Spacer(Modifier.height(6.dp))
        if (hits.isEmpty()) Text("Waiting for data… or no triangle passes your filters.", style = MaterialTheme.typography.bodySmall)
        LazyColumn {
            items(hits, key = { it.id }) { h -> HitRow(h) { vm.openDetail(h) } }
        }
    }
}

@Composable
fun FeedPanel(vm: MainVm) {
    val all by vm.allPairs.collectAsState()
    val relay by vm.useRelay.collectAsState()
    val addr by vm.relayAddr.collectAsState()
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = all, onCheckedChange = { vm.allPairs.value = it })
            Spacer(Modifier.width(8.dp))
            Text("All pairs (any asset can start a triangle)")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = relay, onCheckedChange = { vm.useRelay.value = it })
            Spacer(Modifier.width(8.dp))
            Text("Use ccxt relay instead of direct Binance")
        }
        if (relay) OutlinedTextField(
            value = addr, singleLine = true, label = { Text("Relay host:port") },
            onValueChange = { vm.relayAddr.value = it }
        )
        Button(onClick = { vm.restart() }) { Text("Apply & restart feed") }
    }
}

@Composable
fun FilterPanel(vm: MainVm, f: Filters, fee: Double) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = f.onlyPositive, onCheckedChange = { vm.filters.value = f.copy(onlyPositive = it) })
            Spacer(Modifier.width(8.dp))
            Text("Only profitable after fees")
        }
        Text("Min liquidity: \$${f.minLiqUsd.toInt()}")
        Slider(
            value = f.minLiqUsd.toFloat(), valueRange = 0f..5000f,
            onValueChange = { vm.filters.value = f.copy(minLiqUsd = it.toDouble()) }
        )
        Text("Max leg age: ${f.maxAgeMs / 1000}s (time since a leg's price last changed)")
        Slider(
            value = f.maxAgeMs / 1000f, valueRange = 1f..300f,
            onValueChange = { vm.filters.value = f.copy(maxAgeMs = (it * 1000).toLong()) }
        )
        OutlinedTextField(
            value = f.coin, singleLine = true, label = { Text("Coin (e.g. SOL)") },
            onValueChange = { vm.filters.value = f.copy(coin = it) }
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Fee/trade $fee%")
            listOf(0.1, 0.075, 0.05, 0.0).forEach { x ->
                AssistChip(onClick = { vm.fee.value = x }, label = { Text("$x") })
            }
        }
    }
}

@Composable
fun HitRow(h: Hit, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f)) {
            Text(h.label)
            val alive = if (h.aliveMs > 0) " · alive ${h.aliveMs / 1000}s" else ""
            Text("liq ${fmtUsd(h.maxUsd)} · leg age ${h.ageMs / 1000}s$alive", style = MaterialTheme.typography.bodySmall)
        }
        Text(String.format("%+.3f%%", h.profitPct), color = if (h.profitPct > 0) green else red)
    }
}

@Composable
fun DetailScreen(d: DetailState, vm: MainVm) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp).verticalScroll(rememberScrollState())) {
        TextButton(onClick = { vm.closeDetail() }) { Text("← Back") }
        Text(d.hit.label, style = MaterialTheme.typography.titleLarge)
        Text(
            String.format("Live top-of-book: %+.3f%% · capacity %s", d.hit.profitPct, fmtUsd(d.hit.maxUsd)),
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(12.dp))
        if (d.loading) CircularProgressIndicator()
        d.error?.let { Text(it, color = red) }
        d.legLines.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
        if (d.rows.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text("Depth-verified profit by size", style = MaterialTheme.typography.titleMedium)
            d.rows.forEach { r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(r.label)
                    if (!r.ok) Text("book too thin", color = red)
                    else Text(
                        String.format("%+.3f%%  (%+.2f %s)", r.profitPct, r.net, r.unit),
                        color = if (r.profitPct > 0) green else red
                    )
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = { vm.openDetail(d.hit) }) { Text("Refresh depth") }
    }
}
