package com.example.triarb

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/** Public Binance spot market data only. No API keys, no trading. */
class BinanceFeed : QuoteFeed {
    private val http = OkHttpClient()
    private val rest = "https://data-api.binance.vision"
    private val wsUrl = "wss://data-stream.binance.vision/ws"
    private val sockets = CopyOnWriteArrayList<WebSocket>()
    @Volatile private var closed = false

    override val live = AtomicInteger(0)
    override val messages = AtomicLong(0)
    @Volatile override var total = 0

    override suspend fun loadSymbols(): List<Sym> = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("$rest/api/v3/exchangeInfo?symbolStatus=TRADING").build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw RuntimeException("exchangeInfo HTTP ${r.code}")
            val arr = JSONObject(r.body!!.string()).getJSONArray("symbols")
            (0 until arr.length()).map { arr.getJSONObject(it) }
                .filter { it.getString("status") == "TRADING" && it.optBoolean("isSpotTradingAllowed", true) }
                .map { Sym(it.getString("symbol"), it.getString("baseAsset"), it.getString("quoteAsset")) }
        }
    }

    /** One REST snapshot so quiet pairs have prices before their first stream update. */
    override suspend fun seed(engine: TriangleEngine) = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("$rest/api/v3/ticker/bookTicker").build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw RuntimeException("bookTicker HTTP ${r.code}")
            val arr = JSONArray(r.body!!.string())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                engine.onTick(
                    o.getString("symbol"), o.getString("bidPrice").toDouble(), o.getString("bidQty").toDouble(),
                    o.getString("askPrice").toDouble(), o.getString("askQty").toDouble()
                )
            }
        }
    }

    /** Per-symbol @bookTicker streams, 200 per socket (works without the all-symbols stream). */
    override fun connect(engine: TriangleEngine) {
        val chunks = engine.symbolsUsed.sorted().map { it.lowercase() + "@bookTicker" }.chunked(200)
        total = chunks.size
        chunks.forEachIndexed { i, c -> open(engine, c, i + 1) }
    }

    private fun open(engine: TriangleEngine, streams: List<String>, id: Int) {
        if (closed) return
        val ws = http.newWebSocket(Request.Builder().url(wsUrl).build(), object : WebSocketListener() {
            private var up = false
            override fun onOpen(webSocket: WebSocket, response: Response) {
                up = true; live.incrementAndGet()
                webSocket.send(
                    JSONObject().put("method", "SUBSCRIBE").put("params", JSONArray(streams)).put("id", id).toString()
                )
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val j = JSONObject(text)
                    if (j.has("s")) {
                        messages.incrementAndGet()
                        engine.onTick(
                            j.getString("s"), j.getString("b").toDouble(), j.getString("B").toDouble(),
                            j.getString("a").toDouble(), j.getString("A").toDouble()
                        )
                    }
                } catch (_: Exception) {}
            }
            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) { webSocket.close(1000, null) }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { down(engine, streams, id) }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { down(engine, streams, id) }
            private fun down(e: TriangleEngine, s: List<String>, i: Int) {
                if (up) { up = false; live.decrementAndGet() }
                if (closed) return
                Thread { Thread.sleep(3000); open(e, s, i) }.start()
            }
        })
        sockets.add(ws)
    }

    override suspend fun depth(symbol: String): Book = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("$rest/api/v3/depth?symbol=$symbol&limit=100").build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw RuntimeException("depth $symbol HTTP ${r.code}")
            val j = JSONObject(r.body!!.string())
            Book(levels(j.getJSONArray("bids")), levels(j.getJSONArray("asks")))
        }
    }

    private fun levels(a: JSONArray): List<DoubleArray> = (0 until a.length()).map {
        val l = a.getJSONArray(it)
        doubleArrayOf(l.getString(0).toDouble(), l.getString(1).toDouble())
    }

    override fun close() { closed = true; sockets.forEach { it.cancel() } }
}
