package com.example.triarb

import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

class Book(val bids: List<DoubleArray>, val asks: List<DoubleArray>)

/** A source of live best bid/ask quotes. Implementations: direct Binance, or the ccxt relay. */
interface QuoteFeed {
    val live: AtomicInteger
    val messages: AtomicLong   // ticks received
    val total: Int             // sockets this feed wants open
    suspend fun loadSymbols(): List<Sym>
    suspend fun seed(engine: TriangleEngine)
    fun connect(engine: TriangleEngine)
    suspend fun depth(symbol: String): Book
    fun close()
}
