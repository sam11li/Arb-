package com.example.triarb

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Talks to relay/relay.py (ccxt). Protocol:
 *  ws://host/ws  -> {"type":"markets","symbols":[{"s","b","q"}]} then {"t":[[sym,bid,bidQty,ask,askQty],...]}
 *  send "snapshot" over the socket to get every latest quote again
 *  GET http://host/depth?symbol=SYM -> {"bids":[[p,q]],"asks":[[p,q]]}
 */
class RelayFeed(addr: String) : QuoteFeed {
    private val host = addr.trim().removePrefix("ws://").removePrefix("http://").trimEnd('/')
    private val http = OkHttpClient()
    override val live = AtomicInteger(0)
    override val messages = AtomicLong(0)
    override val total = 1
    @Volatile private var engine: TriangleEngine? = null
    @Volatile private var closed = false
    @Volatile private var ws: WebSocket? = null
    private val markets = CompletableDeferred<List<Sym>>()

    private fun open() {
        if (closed) return
        ws = http.newWebSocket(Request.Builder().url("ws://$host/ws").build(), object : WebSocketListener() {
            private var up = false
            override fun onOpen(webSocket: WebSocket, response: Response) { up = true; live.set(1) }
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val j = JSONObject(text)
                    if (j.optString("type") == "markets") {
                        val arr = j.getJSONArray("symbols")
                        val list = (0 until arr.length()).map { arr.getJSONObject(it) }
                            .map { Sym(it.getString("s"), it.getString("b"), it.getString("q")) }
                        if (!markets.isCompleted) markets.complete(list)
                        if (engine != null) webSocket.send("snapshot")
                    } else if (j.has("t")) {
                        val e = engine ?: return
                        val arr = j.getJSONArray("t")
                        messages.addAndGet(arr.length().toLong())
                        for (i in 0 until arr.length()) {
                            val r = arr.getJSONArray(i)
                            e.onTick(r.getString(0), r.getDouble(1), r.getDouble(2), r.getDouble(3), r.getDouble(4))
                        }
                    }
                } catch (_: Exception) {}
            }
            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) { webSocket.close(1000, null) }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { down() }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (!markets.isCompleted) markets.completeExceptionally(RuntimeException("Cannot reach relay at $host (${t.message})"))
                down()
            }
            private fun down() {
                if (up) { up = false; live.set(0) }
                if (closed) return
                Thread { Thread.sleep(3000); open() }.start()
            }
        })
    }

    override suspend fun loadSymbols(): List<Sym> {
        open()
        return withTimeoutOrNull(15_000) { markets.await() }
            ?: throw RuntimeException("Relay did not answer in 15s (check IP, port, firewall)")
    }

    override suspend fun seed(engine: TriangleEngine) {
        this.engine = engine
        ws?.send("snapshot")
    }

    override fun connect(engine: TriangleEngine) { this.engine = engine } // socket is already open

    override suspend fun depth(symbol: String): Book = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("http://$host/depth?symbol=$symbol").build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw RuntimeException("relay depth HTTP ${r.code}")
            val j = JSONObject(r.body!!.string())
            Book(levels(j.getJSONArray("bids")), levels(j.getJSONArray("asks")))
        }
    }

    private fun levels(a: JSONArray): List<DoubleArray> = (0 until a.length()).map {
        val l = a.getJSONArray(it)
        doubleArrayOf(l.getDouble(0), l.getDouble(1))
    }

    override fun close() { closed = true; ws?.cancel() }
}
