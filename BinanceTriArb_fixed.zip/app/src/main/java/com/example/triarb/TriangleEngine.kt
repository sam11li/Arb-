package com.example.triarb

import java.util.concurrent.ConcurrentHashMap

data class Sym(val name: String, val base: String, val quote: String)

class Quote {
    @Volatile var bid = 0.0
    @Volatile var bidQty = 0.0
    @Volatile var ask = 0.0
    @Volatile var askQty = 0.0
    @Volatile var ts = 0L
}

class Leg(val sym: String, val buy: Boolean, val from: String, val to: String)

class Tri(val id: Int, val start: String, val legs: List<Leg>) {
    val label: String = start + " → " + legs.joinToString(" → ") { it.to }
}

data class Hit(
    val id: Int, val label: String, val start: String, val legs: List<Leg>,
    val profitPct: Double,   // net of fees, top-of-book prices
    val maxUsd: Double,      // top-of-book capacity of the weakest leg, in USD (NaN if start asset has no USDT price)
    val ageMs: Long,         // age of the least recently updated leg
    val aliveMs: Long        // how long the profit has been continuously > 0
)

data class Filters(
    val start: String = "USDT", // "ALL" = any start asset
    val onlyPositive: Boolean = false,
    val minLiqUsd: Double = 0.0,
    val maxAgeMs: Long = 60_000,
    val coin: String = ""
)

/** Finds start -> A -> B -> start loops from live best bid/ask. */
class TriangleEngine(symbols: List<Sym>, starts: List<String>?) {   // starts == null -> every asset can start
    @Volatile var feePct = 0.1 // per trade, percent
    private val quotes = ConcurrentHashMap<String, Quote>()
    private val tris = ArrayList<Tri>()
    private val bySymbol = HashMap<String, MutableList<Int>>()
    private val profits: DoubleArray
    private val posSince: LongArray

    init {
        val out = HashMap<String, MutableList<Leg>>()
        for (s in symbols) {
            out.getOrPut(s.quote) { mutableListOf() }.add(Leg(s.name, true, s.quote, s.base))
            out.getOrPut(s.base) { mutableListOf() }.add(Leg(s.name, false, s.base, s.quote))
        }
        val startList = starts ?: out.keys.toList()
        for (st in startList) for (l1 in out[st].orEmpty()) for (l2 in out[l1.to].orEmpty()) {
            if (l2.to == st || l2.sym == l1.sym) continue
            for (l3 in out[l2.to].orEmpty()) {
                if (l3.to != st || l3.sym == l1.sym || l3.sym == l2.sym) continue
                val i = tris.size
                tris.add(Tri(i, st, listOf(l1, l2, l3)))
                for (l in listOf(l1, l2, l3)) bySymbol.getOrPut(l.sym) { mutableListOf() }.add(i)
            }
        }
        profits = DoubleArray(tris.size) { Double.NaN }
        posSince = LongArray(tris.size)
        for (k in bySymbol.keys) quotes[k] = Quote()
    }

    val triangleCount: Int get() = tris.size
    val symbolsUsed: Set<String> get() = bySymbol.keys

    fun onTick(sym: String, bid: Double, bidQty: Double, ask: Double, askQty: Double) {
        val q = quotes[sym] ?: return
        val now = System.currentTimeMillis()
        q.bid = bid; q.bidQty = bidQty; q.ask = ask; q.askQty = askQty; q.ts = now
        for (i in bySymbol[sym].orEmpty()) {
            val p = eval(tris[i])
            profits[i] = p
            if (p > 0) { if (posSince[i] == 0L) posSince[i] = now } else posSince[i] = 0L
        }
    }

    private fun eval(t: Tri): Double {
        var amt = 1.0
        val keep = 1 - feePct / 100
        for (l in t.legs) {
            val q = quotes[l.sym] ?: return Double.NaN
            if (q.bid <= 0 || q.ask <= 0) return Double.NaN
            amt = (if (l.buy) amt / q.ask else amt * q.bid) * keep
        }
        return (amt - 1) * 100
    }

    /** Largest start amount (in start asset) the top of book of every leg can absorb. */
    private fun maxStart(t: Tri): Double {
        val keep = 1 - feePct / 100
        var m = 1.0 // amount of the current asset held per 1 unit of start asset
        var best = Double.MAX_VALUE
        for (l in t.legs) {
            val q = quotes[l.sym] ?: return 0.0
            if (q.bid <= 0 || q.ask <= 0) return 0.0
            if (l.buy) { best = minOf(best, q.askQty * q.ask / m); m = m / q.ask * keep }
            else { best = minOf(best, q.bidQty / m); m = m * q.bid * keep }
        }
        return best
    }

    fun usdOf(asset: String): Double = when (asset) {
        "USDT", "USDC", "FDUSD" -> 1.0
        else -> quotes[asset + "USDT"]?.bid ?: 0.0
    }

    fun top(f: Filters, n: Int): List<Hit> {
        val now = System.currentTimeMillis()
        val coin = f.coin.trim().uppercase()
        val res = ArrayList<Hit>()
        for (i in tris.indices) {
            val t = tris[i]
            if (f.start != "ALL" && t.start != f.start) continue
            val p = profits[i]
            if (p.isNaN()) continue
            if (f.onlyPositive && p <= 0) continue
            if (coin.isNotEmpty() && t.legs.none { it.to == coin || it.from == coin }) continue
            var oldest = Long.MAX_VALUE
            for (l in t.legs) oldest = minOf(oldest, quotes[l.sym]!!.ts)
            val age = now - oldest
            if (age > f.maxAgeMs) continue
            val usd = usdOf(t.start)
            val capUsd = if (usd > 0) maxStart(t) * usd else Double.NaN
            if (f.minLiqUsd > 0 && !(capUsd >= f.minLiqUsd)) continue
            res.add(Hit(i, t.label, t.start, t.legs, p, capUsd, age, if (posSince[i] > 0) now - posSince[i] else 0))
        }
        res.sortByDescending { it.profitPct }
        return res.take(n)
    }
}
