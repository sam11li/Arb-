package com.example.triarb

data class SimResult(val startAmt: Double, val endAmt: Double, val profitPct: Double, val filled: Boolean)

/** Walks real order-book levels to price a triangle at a given size. */
object DepthSim {
    fun run(legs: List<Leg>, books: Map<String, Book>, start: Double, feePct: Double): SimResult {
        var amt = start
        val keep = 1 - feePct / 100
        for (l in legs) {
            val b = books[l.sym] ?: return SimResult(start, 0.0, -100.0, false)
            amt = if (l.buy) buy(b.asks, amt) else sell(b.bids, amt)
            if (amt < 0) return SimResult(start, 0.0, -100.0, false) // book too thin
            amt *= keep
        }
        return SimResult(start, amt, (amt / start - 1) * 100, true)
    }

    // spend `quote` walking asks; returns base received, or -1 if the book runs out
    private fun buy(asks: List<DoubleArray>, quote: Double): Double {
        var left = quote; var base = 0.0
        for (lvl in asks) {
            val p = lvl[0]; val q = lvl[1]; val cost = p * q
            if (left <= cost) return base + left / p
            base += q; left -= cost
        }
        return -1.0
    }

    // sell `base` walking bids; returns quote received, or -1 if the book runs out
    private fun sell(bids: List<DoubleArray>, base: Double): Double {
        var left = base; var quote = 0.0
        for (lvl in bids) {
            val p = lvl[0]; val q = lvl[1]
            if (left <= q) return quote + left * p
            quote += q * p; left -= q
        }
        return -1.0
    }
}
