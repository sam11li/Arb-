# BinanceTriArb

Android Kotlin/Jetpack Compose scanner for Binance Spot triangular-arbitrage opportunities.

## Relay (optional)

The Python relay uses Binance's public `!bookTicker` WebSocket stream and public REST endpoints for market metadata and order-book depth. It requires Python 3.9+ and `aiohttp`; no API keys, CCXT, or CCXT Pro are required.

```bash
cd relay
python -m pip install -r requirements.txt
python relay.py
```

In the app, enable the relay feed and enter the relay machine's IP address and port `8765`.

## Android build

The GitHub Actions workflow installs Gradle 8.8 and Java 17, then builds `:app:assembleDebug`. The included `gradlew` launcher delegates to the Gradle 8.8 installation provided by that workflow. To create a fully self-contained standard Gradle Wrapper (including `gradle-wrapper.jar`) for local Android Studio use, run `gradle wrapper --gradle-version 8.8` once in an environment with Gradle installed.
