# Binance public-data relay

Requires Python 3.9+.

```bash
python -m pip install -r requirements.txt
python relay.py
```

Optional:
- `--all` streams all active Binance Spot symbols (default: triangle-eligible symbols).
- `--log ticks.csv` appends quote batches to a CSV file.
- `--host 0.0.0.0 --port 8765` changes the listening address/port.

The relay uses Binance public endpoints only. It does not place orders and does
not require Binance API keys, CCXT, or CCXT Pro.
