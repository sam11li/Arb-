#!/usr/bin/env python3
"""
Binance Spot public-market-data relay for TriArb.

Uses Binance's public REST API for exchange metadata/depth and the public
!bookTicker WebSocket stream for live best bid/ask updates. No API keys,
CCXT, or CCXT Pro are required.

Install: pip install -r requirements.txt
Run:     python relay.py
         python relay.py --all --log ticks.csv

App side: Feed -> "Use ccxt relay" -> enter <machine-ip>:8765 -> Apply.
(The existing Android setting label is retained for compatibility.)
"""
import argparse
import asyncio
import csv
import json
import time

import aiohttp
from aiohttp import web

REST_BASE = "https://api.binance.com"
WS_URL = "wss://stream.binance.com:9443/ws/!bookTicker"


def triangle_markets(markets):
    """Keep markets whose base and quote share a third asset (triangle edge)."""
    neighbors = {}
    for market in markets:
        neighbors.setdefault(market["base"], set()).add(market["quote"])
        neighbors.setdefault(market["quote"], set()).add(market["base"])
    return [
        market for market in markets
        if neighbors[market["base"]] & neighbors[market["quote"]]
    ]


async def get_json(session, url, *, params=None):
    async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=20)) as response:
        response.raise_for_status()
        return await response.json()


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--exchange", default="binance", choices=["binance"],
                        help="Binance Spot public market data")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--chunk", type=int, default=200,
                        help="retained for command-line compatibility; Binance uses one all-bookTicker stream")
    parser.add_argument("--all", action="store_true",
                        help="stream every active spot pair, not only pairs participating in triangles")
    parser.add_argument("--log", default="", help="append every tick batch to this CSV file")
    parser.add_argument("--flush", type=float, default=0.1,
                        help="seconds between batches sent to the app")
    args = parser.parse_args()

    http = aiohttp.ClientSession(
        headers={"User-Agent": "BinanceTriArb-Relay/1.0"}
    )
    info = await get_json(http, f"{REST_BASE}/api/v3/exchangeInfo")
    spot = []
    for item in info.get("symbols", []):
        if item.get("status") != "TRADING" or not item.get("isSpotTradingAllowed", True):
            continue
        base, quote, symbol = item.get("baseAsset"), item.get("quoteAsset"), item.get("symbol")
        if not base or not quote or not symbol:
            continue
        spot.append({"id": symbol, "symbol": symbol, "base": base, "quote": quote})
    markets = spot if args.all else triangle_markets(spot)
    by_id = {market["id"]: market for market in markets}
    allowed = set(by_id)
    print(f"binance: {len(spot)} active spot markets; streaming {len(markets)}")

    latest = {}  # symbol -> [bid, bidQty, ask, askQty]
    dirty = set()
    clients = set()
    logf = open(args.log, "a", newline="", buffering=1) if args.log else None
    writer = csv.writer(logf) if logf else None

    async def stream_book_ticker():
        delay = 1
        while True:
            try:
                async with http.ws_connect(
                    WS_URL, heartbeat=30, receive_timeout=75,
                    timeout=aiohttp.ClientTimeout(total=20)
                ) as ws:
                    print("Connected to Binance !bookTicker stream")
                    delay = 1
                    async for message in ws:
                        if message.type == aiohttp.WSMsgType.TEXT:
                            try:
                                event = json.loads(message.data)
                                symbol = event.get("s")
                                if symbol not in allowed:
                                    continue
                                bid, bid_qty = float(event["b"]), float(event["B"])
                                ask, ask_qty = float(event["a"]), float(event["A"])
                                if bid <= 0 or ask <= 0:
                                    continue
                                latest[symbol] = [bid, bid_qty, ask, ask_qty]
                                dirty.add(symbol)
                            except (ValueError, KeyError, TypeError, json.JSONDecodeError):
                                continue
                        elif message.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR):
                            break
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                print("Binance WebSocket error:", type(exc).__name__, exc)
            print(f"Reconnecting to Binance WebSocket in {delay}s")
            await asyncio.sleep(delay)
            delay = min(delay * 2, 30)

    async def flusher():
        while True:
            await asyncio.sleep(max(0.02, args.flush))
            if not dirty:
                continue
            symbols = list(dirty)
            dirty.clear()
            batch = [[symbol, *latest[symbol]] for symbol in symbols if symbol in latest]
            if writer:
                now = time.time()
                for row in batch:
                    writer.writerow([f"{now:.3f}", *row])
            if batch and clients:
                payload = json.dumps({"t": batch}, separators=(",", ":"))
                for ws in list(clients):
                    try:
                        await ws.send_str(payload)
                    except Exception:
                        clients.discard(ws)

    async def ws_handler(request):
        ws = web.WebSocketResponse(heartbeat=20)
        await ws.prepare(request)
        await ws.send_str(json.dumps({
            "type": "markets",
            "exchange": "binance",
            "symbols": [
                {"s": market["id"], "b": market["base"], "q": market["quote"]}
                for market in markets
            ],
        }))
        clients.add(ws)
        try:
            async for message in ws:
                if message.type == web.WSMsgType.TEXT and message.data.strip() == "snapshot":
                    snapshot = [[symbol, *values] for symbol, values in list(latest.items())]
                    await ws.send_str(json.dumps({"t": snapshot}, separators=(",", ":")))
        finally:
            clients.discard(ws)
        return ws

    async def depth(request):
        symbol = request.query.get("symbol", "").upper()
        if symbol not in by_id:
            return web.json_response({"error": "unknown symbol"}, status=404)
        try:
            data = await get_json(
                http, f"{REST_BASE}/api/v3/depth",
                params={"symbol": symbol, "limit": 100}
            )
            return web.json_response({
                "bids": [[float(price), float(quantity)] for price, quantity in data.get("bids", [])],
                "asks": [[float(price), float(quantity)] for price, quantity in data.get("asks", [])],
            })
        except (aiohttp.ClientError, asyncio.TimeoutError, ValueError) as exc:
            return web.json_response({"error": str(exc)}, status=502)

    app = web.Application()
    app.add_routes([web.get("/ws", ws_handler), web.get("/depth", depth)])
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, args.host, args.port).start()
    print(f"relay listening on {args.host}:{args.port} (WebSocket /ws; HTTP /depth?symbol=...)")

    tasks = [
        asyncio.create_task(stream_book_ticker()),
        asyncio.create_task(flusher()),
    ]
    try:
        await asyncio.gather(*tasks)
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        await runner.cleanup()
        if logf:
            logf.close()
        await http.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
